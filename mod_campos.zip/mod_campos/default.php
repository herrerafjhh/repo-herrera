<?php 
// No direct access
defined('_JEXEC') or die; ?>



<?php if (!empty($grupos)) : ?>
	<div class="campo-module<?php echo $moduleclass_sfx; ?>">
	<?php foreach ($grupo as $item) : ?>
            <div class="grupo-module>
                    <?php echo $item; ?>">
                    <?php if (!empty($usuarios)) : ?>
                        <?php foreach ($usuarios as $item2) : ?>
                        <div class="usuario-module>
                            <?php echo $item2; ?>">
                        </div>        
                        <?php endforeach; ?>
                    <?php endif; ?>
            </div>
	<?php endforeach; ?>
</div>
<?php endif; ?>