CREATE TABLE IF NOT EXISTS `Grupo` (
	`id` int(10) NOT NULL AUTO_INCREMENT,
	`nombre` varchar(25) NOT NULL,
 
  PRIMARY KEY (`id`)
) ENGINE=INNODB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;
 
INSERT INTO `Grupo` (`nombre`) VALUES ('Grupo 1');
INSERT INTO `Grupo` (`nombre`) VALUES ('Grupo 2');
INSERT INTO `Grupo` (`nombre`) VALUES ('Grupo 3');
INSERT INTO `Grupo` (`nombre`) VALUES ('Grupo 4');
INSERT INTO `Grupo` (`nombre`) VALUES ('Grupo 5');
INSERT INTO `Grupo` (`nombre`) VALUES ('Grupo 6');


CREATE TABLE IF NOT EXISTS `Usuario` (
	`id` int(10) NOT NULL AUTO_INCREMENT,
	`nombre` varchar(25) NOT NULL,
        `id_grupo` int(10) NOT NULL,
        
 
  PRIMARY KEY (`id`),
  INDEX `fk_Usuario_Grupo_idx` (`id_grupo` ASC) ,
  CONSTRAINT `fk_Usuario_Grupo`
    FOREIGN KEY (`id_grupo`)
) ENGINE=INNODB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;
 
INSERT INTO `Usuario` (`nombre`,`id_grupo`) VALUES ('Usuario 1',1);
INSERT INTO `Usuario` (`nombre`,`id_grupo`) VALUES ('Usuario 2',1);
INSERT INTO `Usuario` (`nombre`,`id_grupo`) VALUES ('Usuario 3',1);
INSERT INTO `Usuario` (`nombre`,`id_grupo`) VALUES ('Usuario 4',2);
INSERT INTO `Usuario` (`nombre`,`id_grupo`) VALUES ('Usuario 5',5);
INSERT INTO `Usuario` (`nombre`,`id_grupo`) VALUES ('Usuario 6',2);
INSERT INTO `Usuario` (`nombre`,`id_grupo`) VALUES ('Usuario 7',3);
INSERT INTO `Usuario` (`nombre`,`id_grupo`) VALUES ('Usuario 8',8);
INSERT INTO `Usuario` (`nombre`,`id_grupo`) VALUES ('Usuario 9',3);
INSERT INTO `Usuario` (`nombre`,`id_grupo`) VALUES ('Usuario 10',4);
INSERT INTO `Usuario` (`nombre`,`id_grupo`) VALUES ('Usuario 11',4);
INSERT INTO `Usuario` (`nombre`,`id_grupo`) VALUES ('Usuario 12',4);
INSERT INTO `Usuario` (`nombre`,`id_grupo`) VALUES ('Usuario 13',5);
INSERT INTO `Usuario` (`nombre`,`id_grupo`) VALUES ('Usuario 14',5);
INSERT INTO `Usuario` (`nombre`,`id_grupo`) VALUES ('Usuario 15',5);
INSERT INTO `Usuario` (`nombre`,`id_grupo`) VALUES ('Usuario 16',6);
INSERT INTO `Usuario` (`nombre`,`id_grupo`) VALUES ('Usuario 17',6);
INSERT INTO `Usuario` (`nombre`,`id_grupo`) VALUES ('Usuario 18',6);
INSERT INTO `Usuario` (`nombre`,`id_grupo`) VALUES ('Usuario 19',2);
INSERT INTO `Usuario` (`nombre`,`id_grupo`) VALUES ('Usuario 20',3);
INSERT INTO `Usuario` (`nombre`,`id_grupo`) VALUES ('Usuario 21',4);
INSERT INTO `Usuario` (`nombre`,`id_grupo`) VALUES ('Usuario 22',4);